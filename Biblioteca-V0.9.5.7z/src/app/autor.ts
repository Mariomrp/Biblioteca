export class Autor {
    nome: string;
    origem: string;
}