import { Injectable } from '@angular/core';
import { Retirada } from 'app/retirada';
import { Usuario } from "app/usuario";
import { Livro } from "app/livro";

@Injectable()
export class RetiradaService {

  constructor() { }

// getListaLivros() {
//   return this.livros;
// }

// getListaUsuarios() {
//   return this.usuarios;
// }

}
