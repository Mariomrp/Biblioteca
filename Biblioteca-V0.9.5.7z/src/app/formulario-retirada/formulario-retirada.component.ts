import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-formulario-retirada',
  templateUrl: './formulario-retirada.component.html',
  styleUrls: ['./formulario-retirada.component.css']
})
export class FormularioRetiradaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
