export class Retirada {
    
}