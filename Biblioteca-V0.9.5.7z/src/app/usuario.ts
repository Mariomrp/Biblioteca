export class Usuario {
    matricula: string;
    nome: string;
    email: string;
    telefone: string;
}
