export class Livro {
    isbn: string;
    nome: string;
    autor: string;
    editora: string;
    anopublicacao: string;
}